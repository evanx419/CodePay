<?php 
  $db = "guavacod_codepay"; //database name
  $dbuser = "guavacod_codepay"; //database username
  $dbpassword = "Vv3l34f7#SYI@f"; //database password
  $dbhost = "localhost"; //database host


  $return["error"] = false;
  $return["message"] = "";

  $link = mysqli_connect($dbhost, $dbuser, $dbpassword, $db);
  
  
 
  $val = isset($_POST["imgUrl"]) && $_POST["wallet_id"];

  if($val){
       //checking if there is POST data

       
       $imgurl = $_POST["imgUrl"];
       $wallet = $_POST["wallet_id"];

    
       
       //if there is no any error then ready for database write
       if($return["error"] == false){
            
            $imgurl = mysqli_real_escape_string($link, $imgurl);
            $wallet = mysqli_real_escape_string($link, $wallet);
            
            
            //escape inverted comma query conflict from string

            
            
            // echo("here");
            
            
            $sql = "UPDATE `usersdb` SET `imgUrl`= '$imgurl' WHERE `wallet_id`= '$wallet'";
            //student_id is with AUTO_INCREMENT, so its value will increase automatically

            $res = mysqli_query($link, $sql);
            if($res){
                $return["error"] = false;
      $return["message"] = 'Successful.';
            }else{
                $return["error"] = true;
                $return["message"] = "Database error";
            }
       }
  }else{
      $return["error"] = true;
      $return["message"] = 'Send all parameters.';
  }

  mysqli_close($link); //close mysqli

  header('Content-Type: application/json');
  // tell browser that its a json data
  echo json_encode($return);
  //converting array to JSON string
?>