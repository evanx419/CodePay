<?php 
  $db = "guavacod_codepay"; //database name
  $dbuser = "guavacod_codepay"; //database username
  $dbpassword = "Vv3l34f7#SYI@f"; //database password
  $dbhost = "localhost"; //database host

  $return["error"] = false;
  $return["message"] = "";

  $link = mysqli_connect($dbhost, $dbuser, $dbpassword, $db);
  //connecting to database server
//   if($link){
//       echo("true");
//   }


// INSERT INTO `users`(`id`, `email`, `wallet_id`, `imgUrl`, `pwd`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5])

  $val = isset($_POST["myWallet"]);

  if($val){
       
       $myWallet = $_POST["myWallet"];
      
       

       //add more validations here

       //if there is no any error then ready for database write
       if($return["error"] == false){
            $myWallet = mysqli_real_escape_string($link, $myWallet);
            
           
            //escape inverted comma query conflict from string
            
            // DELETE FROM `business` WHERE 0
            
            // echo("here");
            $sql = "DELETE FROM `payment` WHERE `myWallet` = '$myWallet' ";
            
            //student_id is with AUTO_INCREMENT, so its value will increase automatically

            $res = mysqli_query($link, $sql);
            
            if($res){
                $return["error"] = false;
      $return["message"] = 'Successful.';
            }else{
                $return["error"] = true;
                $return["message"] = "Database error";
            }
       }
  }else{
      $return["error"] = true;
      $return["message"] = 'Send all parameters.';
  }

  mysqli_close($link); //close mysqli

  header('Content-Type: application/json');
  // tell browser that its a json data
  echo json_encode($return);
  //converting array to JSON string
?>
