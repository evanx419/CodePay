<?php 
  $db = "guavacod_codepay"; //database name
  $dbuser = "guavacod_codepay"; //database username
  $dbpassword = "Vv3l34f7#SYI@f"; //database password
  $dbhost = "localhost"; //database host

  $return["error"] = false;
  $return["message"] = "";
  

  $link = mysqli_connect($dbhost, $dbuser, $dbpassword, $db);
 
 
  $val = isset($_POST["mywallet"]) && isset($_POST["method"])
         && isset($_POST["amount"]) && isset($_POST["status"]) && isset($_POST["balance"]) && isset($_POST["currency"]) && isset($_POST["number"]);

  if($val){

       $mywallet = $_POST["mywallet"];
       
       $method = $_POST["method"];
        
        $amount = $_POST["amount"]; 
        
        $status = $_POST["status"];
        
        $balance = $_POST["balance"]; 
        
        $currency = $_POST["currency"]; 
        
        $number = $_POST["number"];

      
      
       if($return["error"] == false){
            $mywallet  = mysqli_real_escape_string($link,  $mywallet);
            $method = mysqli_real_escape_string($link, $method);
            $amount = mysqli_real_escape_string($link, $amount);
            $status = mysqli_real_escape_string($link, $status);
            $balance = mysqli_real_escape_string($link, $balance);
            $currency = mysqli_real_escape_string($link, $currency);
           $number = mysqli_real_escape_string($link, $number);
           
            //escape inverted comma query conflict from string

            
            // echo("here");
            
            $sql = "INSERT INTO `payment`(`Id`, `mywallet`, `method`, `amount`, `balance`, `status`, `currency`, `postId`, `number`) VALUES (null,'$mywallet','$method','$amount','$balance','$status','$currency','null', '$number')";



            $res = mysqli_query($link, $sql);
            if($res){
                $return["error"] = false;
      $return["message"] = 'Successful.';
            }else{
                $return["error"] = true;
                $return["message"] = "Database error";
            }
       }
  }else{
      $return["error"] = true;
      $return["message"] = 'Send all parameters.';
  }

  mysqli_close($link); //close mysqli

  header('Content-Type: application/json');
  // tell browser that its a json data
  echo json_encode($return);
  //converting array to JSON string
?>
