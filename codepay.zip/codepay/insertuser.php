<?php 
  $db = "guavacod_codepay"; //database name
  $dbuser = "guavacod_codepay"; //database username
  $dbpassword = "Vv3l34f7#SYI@f"; //database password
  $dbhost = "localhost"; //database host

  $return["error"] = false;
  $return["message"] = "";

  $link = mysqli_connect($dbhost, $dbuser, $dbpassword, $db);
  //connecting to database server
//   if($link){
//       echo("true");
//   }


// INSERT INTO `users`(`id`, `email`, `wallet_id`, `imgUrl`, `pwd`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5])

  $val = isset($_POST["email"]) && isset($_POST["wallet_id"])
         && isset($_POST["imgUrl"]) && isset($_POST["pwd"]) && isset($_POST["ref_id"]);

  if($val){
       //checking if there is POST data

       $email = $_POST["email"]; //grabing the data from headers
       $wallet = $_POST["wallet_id"];
       $ref = $_POST["ref_id"];
       $imgurl = $_POST["imgUrl"];
       $pwd = $_POST["pwd"];
       
       //validation name if there is no error before
       if($return["error"] == false && strlen($pwd) < 4){
           $return["error"] = true;
           $return["message"] = "password too short";
       }

       //add more validations here

       //if there is no any error then ready for database write
       if($return["error"] == false){
            $email = mysqli_real_escape_string($link, $email);
            $wallet = mysqli_real_escape_string($link, $wallet);
            $ref = mysqli_real_escape_string($link, $ref);
            $imgurl = mysqli_real_escape_string($link, $imgurl);
            $pwd = mysqli_real_escape_string($link, $pwd);
           
            //escape inverted comma query conflict from string

            // $sql ="INSERT INTO student_list SET id = null, email = '$email', wallet_id = '$wallet', imgUrl = '$imgurl', pwd = '$pwd'"; 
            
            // echo("here");
            $sql = "INSERT INTO `usersdb`(`id`, `email`, `wallet_id`, `ref_id`, `imgUrl`, `pwd`) VALUES (null,'$email','$wallet','$ref','$imgurl','$pwd')";
            //student_id is with AUTO_INCREMENT, so its value will increase automatically

            $res = mysqli_query($link, $sql);
            if($res){
                $return["error"] = false;
      $return["message"] = 'Successful.';
            }else{
                $return["error"] = true;
                $return["message"] = "Database error";
            }
       }
  }else{
      $return["error"] = true;
      $return["message"] = 'Send all parameters.';
  }

  mysqli_close($link); //close mysqli

  header('Content-Type: application/json');
  // tell browser that its a json data
  echo json_encode($return);
  //converting array to JSON string
?>
