<?php 
  $db = "guavacod_codepay"; //database name
  $dbuser = "guavacod_codepay"; //database username
  $dbpassword = "Vv3l34f7#SYI@f"; //database password
  $dbhost = "localhost"; //database host

  $return["error"] = false;
  $return["message"] = "";

  $link = mysqli_connect($dbhost, $dbuser, $dbpassword, $db);
  //connecting to database server
//   if($link){
//       echo("true");
//   }


// INSERT INTO `users`(`id`, `email`, `wallet_id`, `imgUrl`, `pwd`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5])

  $val = isset($_POST["mywallet"]) && isset($_POST["wallet"])
         && isset($_POST["amount"]) && isset($_POST["status"]) && isset($_POST["postId"]) && isset($_POST["balance"]) && isset($_POST["currency"]) && isset($_POST["number"]);

  if($val){
       //checking if there is POST data
       
       
       $mywallet = $_POST["mywallet"];
       
       $wallet = $_POST["wallet"];
        
        $amount = $_POST["amount"]; 
        
        $status = $_POST["status"];
        
        $postId = $_POST["postId"];
        
        $balance = $_POST["balance"]; 
        
        $currency = $_POST["currency"]; 
        
        $number = $_POST["number"];

      
      

       //add more validations here

       //if there is no any error then ready for database write
       if($return["error"] == false){
             $mywallet  = mysqli_real_escape_string($link,  $mywallet);
            $wallet = mysqli_real_escape_string($link, $wallet);
            $amount = mysqli_real_escape_string($link, $amount);
            $status = mysqli_real_escape_string($link, $status);
            $postId = mysqli_real_escape_string($link, $postId);
            $balance = mysqli_real_escape_string($link, $balance);
            $currency = mysqli_real_escape_string($link, $currency);
           $number = mysqli_real_escape_string($link, $number);
           
            //escape inverted comma query conflict from string

            
            // echo("here");
            $sql = "INSERT INTO `payout`(`Id`, `mywallet`, `wallet`, `amount`, `balance`, `status`, `currency`, `postId`, `number`) VALUES (null,'$mywallet','$wallet','$amount','$balance','$status','$currency','$postId', '$number')";



            $res = mysqli_query($link, $sql);
            if($res){
                $return["error"] = false;
      $return["message"] = 'Successful.';
            }else{
                $return["error"] = true;
                $return["message"] = "Database error";
            }
       }
  }else{
      $return["error"] = true;
      $return["message"] = 'Send all parameters.';
  }

  mysqli_close($link); //close mysqli

  header('Content-Type: application/json');
  // tell browser that its a json data
  echo json_encode($return);
  //converting array to JSON string
?>
