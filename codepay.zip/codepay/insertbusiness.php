<?php 
  $db = "guavacod_codepay"; //database name
  $dbuser = "guavacod_codepay"; //database username
  $dbpassword = "Vv3l34f7#SYI@f"; //database password
  $dbhost = "localhost"; //database host

  $return["error"] = false;
  $return["message"] = "";

  $link = mysqli_connect($dbhost, $dbuser, $dbpassword, $db);
  //connecting to database server
//   if($link){
//       echo("true");
//   }


// INSERT INTO `users`(`id`, `email`, `wallet_id`, `imgUrl`, `pwd`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5])

  $val = isset($_POST["description"]) && isset($_POST["wallet"])
         && isset($_POST["img"]) && isset($_POST["amount"]) && isset($_POST["date"]) && ($_POST["currency"]) && ($_POST["status"]) && isset($_POST["phone"]);

  if($val){
       //checking if there is POST data

       $description = $_POST["description"]; //grabing the data from headers
       $wallet = $_POST["wallet"];
       $amount = $_POST["amount"];
       $imgurl = $_POST["img"];
       $date = $_POST["date"];
       $name = $_POST["name"];
       $currency = $_POST["currency"];
       $status = $_POST["status"];
       $phone = $_POST["phone"];
       

       //add more validations here

       //if there is no any error then ready for database write
       if($return["error"] == false){
             $description  = mysqli_real_escape_string($link,  $description);
            $wallet = mysqli_real_escape_string($link, $wallet);
            $amount = mysqli_real_escape_string($link, $amount);
            $imgurl = mysqli_real_escape_string($link, $imgurl);
            $date= mysqli_real_escape_string($link, $date);
            $name= mysqli_real_escape_string($link, $name);
            $currency= mysqli_real_escape_string($link, $currency);
           $status= mysqli_real_escape_string($link, $status);
            $phone= mysqli_real_escape_string($link, $phone);
           
           
           
            //escape inverted comma query conflict from string

            // $sql ="INSERT INTO student_list SET id = null, email = '$email', wallet_id = '$wallet', imgUrl = '$imgurl', pwd = '$pwd'"; 
            
            // echo("here");
            $sql = "INSERT INTO `business`(`id`, `name`, `description`, `amount`, `phone`, `payoutcurrency`, `date`, `img`, `wallet`, `status`) VALUES (null,'$name','$description','$amount','$phone','$currency','$date','$imgurl','$wallet', '$status')";
            
            //student_id is with AUTO_INCREMENT, so its value will increase automatically

            $res = mysqli_query($link, $sql);
            if($res){
                $return["error"] = false;
      $return["message"] = 'Successful.';
            }else{
                $return["error"] = true;
                $return["message"] = "Database error";
            }
       }
  }else{
      $return["error"] = true;
      $return["message"] = 'Send all parameters.';
  }

  mysqli_close($link); //close mysqli

  header('Content-Type: application/json');
  // tell browser that its a json data
  echo json_encode($return);
  //converting array to JSON string
?>
