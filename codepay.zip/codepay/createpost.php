<?php 
  $db = "guavacod_codepay"; //database name
  $dbuser = "guavacod_codepay"; //database username
  $dbpassword = "Vv3l34f7#SYI@f"; //database password
  $dbhost = "localhost"; //database host

  $return["error"] = false;
  $return["message"] = "";

  $link = mysqli_connect($dbhost, $dbuser, $dbpassword, $db);


$val = isset($_POST["message"]) && isset($_POST["name"]) && isset($_POST["country"]) && isset($_POST["date"]) && isset($_POST["eWallet"]);

  if($val){
       //checking if there is POST data
       
       
        $message = $_POST["message"];
        
        $name = $_POST["name"];
        
        $country = $_POST["country"]; 
        
        $date = $_POST["date"];
        
        $eWallet= $_POST["eWallet"];

      
      

       //add more validations here

       //if there is no any error then ready for database write
       if($return["error"] == false){
             $message  = mysqli_real_escape_string($link,  $message);
            $name = mysqli_real_escape_string($link, $name);
            $date = mysqli_real_escape_string($link, $date);
            $country = mysqli_real_escape_string($link, $country);
            $eWallet = mysqli_real_escape_string($link, $eWallet);
            

            
            // echo("here");
            $sql = "INSERT INTO `meetup`(`id`, `eWallet`, `message`, `name`, `country`, `date`) VALUES (null,'$eWallet','$message','$name','$country','$date')";



            $res = mysqli_query($link, $sql);
            if($res){
                $return["error"] = false;
      $return["message"] = 'Successful.';
            }else{
                $return["error"] = true;
                $return["message"] = "Database error";
            }
       }
  }else{
      $return["error"] = true;
      $return["message"] = 'Send all parameters.';
  }

  mysqli_close($link); //close mysqli

  header('Content-Type: application/json');
  // tell browser that its a json data
  echo json_encode($return);
  //converting array to JSON string
?>
