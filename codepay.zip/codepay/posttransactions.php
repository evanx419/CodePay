<?php 
  $db = "guavacod_codepay"; //database name
  $dbuser = "guavacod_codepay"; //database username
  $dbpassword = "Vv3l34f7#SYI@f"; //database password
  $dbhost = "localhost"; //database host

  $return["error"] = false;
  $return["message"] = "";

  $link = mysqli_connect($dbhost, $dbuser, $dbpassword, $db);
  //connecting to database server
//   if($link){
//       echo("true");
//   }


// INSERT INTO `users`(`id`, `email`, `wallet_id`, `imgUrl`, `pwd`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5])

  $val = isset($_POST["balance"]) && isset($_POST["ewallet"])
          && isset($_POST["myWallet"]) && isset($_POST["date"]) && ($_POST["currency"]) && ($_POST["postId"]) && ($_POST["number"]);;

  if($val){
       //checking if there is POST data

       $balance = $_POST["balance"]; //grabing the data from headers
       $ewallet = $_POST["ewallet"];
       $date = $_POST["date"];
       $myWallet = $_POST["myWallet"];
       $currency = $_POST["currency"];
       $postId = $_POST["postId"];
        $number = $_POST["number"];
       

       //add more validations here

       //if there is no any error then ready for database write
       if($return["error"] == false){
             $balance  = mysqli_real_escape_string($link,  $balance);
            $ewallet = mysqli_real_escape_string($link, $ewallet);
            $date= mysqli_real_escape_string($link, $date);
            $myWallet = mysqli_real_escape_string($link, $myWallet);
            $currency = mysqli_real_escape_string($link, $currency);
            $postId = mysqli_real_escape_string($link, $postId);
           $number = mysqli_real_escape_string($link, $number);
           
           
           
            //escape inverted comma query conflict from string

            // $sql ="INSERT INTO student_list SET id = null, email = '$email', wallet_id = '$wallet', imgUrl = '$imgurl', pwd = '$pwd'"; 
            
            // echo("here");
            $sql = "INSERT INTO `businesstrx` (`id`, `balance`, `ewallet`, `myWallet`, `currency`, `postId`, `date`, `number`) VALUES (null,'$balance','$ewallet','$myWallet','$currency','$postId','$date','$number')";
            
            //student_id is with AUTO_INCREMENT, so its value will increase automatically

            $res = mysqli_query($link, $sql);
            if($res){
                $return["error"] = false;
      $return["message"] = 'Successful.';
            }else{
                $return["error"] = true;
                $return["message"] = "Database error";
            }
       }
  }else{
      $return["error"] = true;
      $return["message"] = 'Send all parameters.';
  }

  mysqli_close($link); //close mysqli

  header('Content-Type: application/json');
  // tell browser that its a json data
  echo json_encode($return);
  //converting array to JSON string
?>
